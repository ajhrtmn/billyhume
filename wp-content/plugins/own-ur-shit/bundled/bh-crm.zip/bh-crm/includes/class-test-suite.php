<?php
if (!defined('ABSPATH')) exit;

/**
 * OUS_TestRunner suite for bh-crm — same convention as the rest of the
 * ecosystem's own class-test-suite.php files. This plugin had ZERO test
 * coverage before this pass. Covers BHCRM_Segments::sanitize_conditions()
 * (the server-side validation that stands between a raw $_POST array and
 * what actually gets run as a user filter), BHCRM_Export::csv_safe()
 * (the CSV-injection guard), and BHCRM_Subtasks' pure tree-manipulation
 * helpers (find_node()/children_at()/total_node_count()).
 */
class BHCRM_TestSuite {
    public static function init() {
        add_filter('bhcore_test_suites', [self::class, 'register']);
    }

    public static function register($suites) {
        $suites['bh-crm'] = ['label' => 'BH CRM', 'callback' => [self::class, 'run']];
        return $suites;
    }

    public static function run() {
        if (!class_exists('OUS_TestRunner') || !class_exists('BHCRM_Segments')) {
            return [['name' => 'BHCRM_Segments not loaded', 'pass' => false, 'message' => 'Skipped — required classes not found.']];
        }
        $rows = [];
        $rows = array_merge($rows, self::run_segment_condition_tests());
        $rows = array_merge($rows, self::run_csv_safe_tests());
        $rows = array_merge($rows, self::run_subtasks_tree_tests());
        if (class_exists('BHCRM_Projects')) {
            $rows = array_merge($rows, self::run_project_scene_tests());
        }
        if (class_exists('BHCRM_Projects') && class_exists('BH_Element')) {
            $rows = array_merge($rows, self::run_stall_analytics_tests());
        }
        return $rows;
    }

    /* ---------- Phase C: stall analytics ---------- */

    private static function run_stall_analytics_tests() {
        $rows = [];
        global $wpdb;

        $project_id = BHCRM_Projects::create('Stall Suite Test Project', 0, [], '');

        // A real bh/sticky-card placement, created through the SAME
        // save_placement() write path a live board uses — this is what
        // exercises the 'bhcore_element_placement_saved' hook for real,
        // not a mock of it.
        $card_id = BH_Element::save_placement([
            'surface' => 'bhcrm_project_board', 'surface_context_id' => $project_id, 'slot' => 'board',
            'position' => 0, 'element_type' => 'bh/sticky-card',
            'config' => ['attrs' => ['title' => 'Suite Test Card', 'column' => 'To Do']],
        ]);
        $rows[] = OUS_TestRunner::assert_true($card_id > 0, 'A real bh/sticky-card placement is created via save_placement()');

        $moves_table = $wpdb->prefix . 'bhcrm_project_card_moves';
        $initial_count = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $moves_table WHERE card_placement_id = %d", $card_id));
        $rows[] = OUS_TestRunner::assert_same(1, $initial_count, 'Creating a card logs exactly one initial move row (its starting column)');

        // An unrelated edit (title only, same column) must NOT log a
        // second move — this is the whole point of diffing old vs. new
        // config rather than logging on every save.
        BH_Element::save_placement([
            'id' => $card_id,
            'surface' => 'bhcrm_project_board', 'surface_context_id' => $project_id, 'slot' => 'board',
            'position' => 0, 'element_type' => 'bh/sticky-card',
            'config' => ['attrs' => ['title' => 'Suite Test Card (renamed)', 'column' => 'To Do']],
        ]);
        $count_after_rename = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $moves_table WHERE card_placement_id = %d", $card_id));
        $rows[] = OUS_TestRunner::assert_same(1, $count_after_rename, 'Saving the SAME column again (a title-only edit) does not log a second move');

        // A real column change DOES log a new move.
        BH_Element::save_placement([
            'id' => $card_id,
            'surface' => 'bhcrm_project_board', 'surface_context_id' => $project_id, 'slot' => 'board',
            'position' => 0, 'element_type' => 'bh/sticky-card',
            'config' => ['attrs' => ['title' => 'Suite Test Card (renamed)', 'column' => 'In Progress']],
        ]);
        $count_after_move = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $moves_table WHERE card_placement_id = %d", $card_id));
        $rows[] = OUS_TestRunner::assert_same(2, $count_after_move, 'A real column change logs a second move row');

        // average_hours_per_column() — checked HERE, before any
        // backdating below, while both move rows are still in their
        // real chronological order. The first card had a real,
        // measurable completed stay in "To Do" (its very first move) up
        // until it moved to "In Progress." That completed stay is the
        // ONLY thing average_hours_per_column() should count for "To
        // Do" — the CURRENT stay in "In Progress" hasn't ended yet and
        // must be excluded.
        $averages = BHCRM_Projects::average_hours_per_column($project_id);
        $rows[] = OUS_TestRunner::assert_true(isset($averages['To Do']), 'average_hours_per_column() reports a completed stay for "To Do"');
        $rows[] = OUS_TestRunner::assert_false(isset($averages['In Progress']), 'average_hours_per_column() excludes "In Progress" — that stay has not ended yet');

        // Backdate BOTH moves so the card reads as stalled — direct
        // SQL, not the public API, since "make time pass" isn't
        // something a real call can do. Deliberately done AFTER the
        // average_hours_per_column() check above (backdating before
        // that check would corrupt the chronological ordering it
        // depends on). BOTH rows need backdating, not just the most
        // recent one: a real test-design bug caught while writing this
        // suite (not a product bug) — backdating only the second
        // (most recent) row left the FIRST row's timestamp (still
        // "now," from its real insert moment) chronologically AFTER
        // the artificially-aged second row, so MAX(entered_at) picked
        // the first row and the card read as completely fresh instead
        // of stalled. Backdating both, in the correct relative order,
        // is what actually simulates "this card moved here N days ago
        // and has sat since."
        $wpdb->query($wpdb->prepare(
            "UPDATE $moves_table SET entered_at = %s WHERE card_placement_id = %d ORDER BY id ASC LIMIT 1",
            gmdate('Y-m-d H:i:s', time() - (BHCRM_Projects::STALL_DAYS + 10) * DAY_IN_SECONDS), $card_id
        ));
        $wpdb->query($wpdb->prepare(
            "UPDATE $moves_table SET entered_at = %s WHERE card_placement_id = %d ORDER BY id DESC LIMIT 1",
            gmdate('Y-m-d H:i:s', time() - (BHCRM_Projects::STALL_DAYS + 2) * DAY_IN_SECONDS), $card_id
        ));

        $stalled = BHCRM_Projects::stalled_cards_for_board($project_id);
        $rows[] = OUS_TestRunner::assert_true(isset($stalled[$card_id]) && $stalled[$card_id] >= BHCRM_Projects::STALL_DAYS, 'stalled_cards_for_board() flags a card whose most recent move is older than STALL_DAYS');

        // A second card whose only move is recent should NOT show up.
        $fresh_card_id = BH_Element::save_placement([
            'surface' => 'bhcrm_project_board', 'surface_context_id' => $project_id, 'slot' => 'board',
            'position' => 1, 'element_type' => 'bh/sticky-card',
            'config' => ['attrs' => ['title' => 'Fresh Card', 'column' => 'To Do']],
        ]);
        $stalled_after_fresh = BHCRM_Projects::stalled_cards_for_board($project_id);
        $rows[] = OUS_TestRunner::assert_false(isset($stalled_after_fresh[$fresh_card_id]), 'A card whose only move is recent is NOT flagged as stalled');

        // Cleanup
        $wpdb->delete($moves_table, ['card_placement_id' => $card_id]);
        $wpdb->delete($moves_table, ['card_placement_id' => $fresh_card_id]);
        BH_Element::delete_placement($card_id);
        BH_Element::delete_placement($fresh_card_id);
        BHCRM_Projects::delete($project_id);

        return $rows;
    }

    /* ---------- PROJECT-TRACKER-TRACKIT-PARITY-PLAN.md Phase E: scene ---------- */

    private static function run_project_scene_tests() {
        $rows = [];

        $id_scened = BHCRM_Projects::create('Scene Suite Test Project A', 0, [], 'Album Launch');
        $id_unscened = BHCRM_Projects::create('Scene Suite Test Project B', 0, [], '');

        $rows[] = OUS_TestRunner::assert_true($id_scened > 0 && $id_unscened > 0, 'create() succeeds both with and without a scene');

        $scened = BHCRM_Projects::get($id_scened);
        $rows[] = OUS_TestRunner::assert_same('Album Launch', $scened['scene'] ?? null, 'A scene passed to create() is stored and read back exactly');

        $unscened = BHCRM_Projects::get($id_unscened);
        $rows[] = OUS_TestRunner::assert_same('', $unscened['scene'] ?? null, 'Omitting a scene at creation stores an empty string, not null/false');

        $updated = BHCRM_Projects::update_scene($id_unscened, 'Merch Drop');
        $rows[] = OUS_TestRunner::assert_true($updated, 'update_scene() succeeds against an existing project');
        $after_update = BHCRM_Projects::get($id_unscened);
        $rows[] = OUS_TestRunner::assert_same('Merch Drop', $after_update['scene'] ?? null, 'update_scene() actually persists the new value');

        $scenes = BHCRM_Projects::distinct_scenes();
        $rows[] = OUS_TestRunner::assert_true(in_array('Album Launch', $scenes, true) && in_array('Merch Drop', $scenes, true), 'distinct_scenes() includes every non-empty scene currently in use');
        $rows[] = OUS_TestRunner::assert_false(in_array('', $scenes, true), 'distinct_scenes() never includes the empty/unsorted scene as a suggestion');

        // Cleanup
        BHCRM_Projects::delete($id_scened);
        BHCRM_Projects::delete($id_unscened);

        return $rows;
    }

    /* ---------- BHCRM_Segments::sanitize_conditions() ---------- */

    private static function run_segment_condition_tests() {
        $rows = [];

        $clean = BHCRM_Segments::sanitize_conditions([
            ['field' => 'tag', 'value' => 'vip'],
        ]);
        $rows[] = OUS_TestRunner::assert_same(
            [['field' => 'tag', 'value' => 'vip']], $clean,
            'sanitize_conditions(): a well-formed condition passes through unchanged'
        );

        $rows[] = OUS_TestRunner::assert_same(
            [], BHCRM_Segments::sanitize_conditions([['field' => 'not_a_real_field', 'value' => 'x']]),
            'sanitize_conditions(): an unknown field is dropped entirely, never persisted as a filterable condition'
        );

        $rows[] = OUS_TestRunner::assert_same(
            [], BHCRM_Segments::sanitize_conditions([['field' => 'tag', 'value' => '']]),
            'sanitize_conditions(): tag with an empty value is dropped (every field except has_project requires a real value)'
        );

        $rows[] = OUS_TestRunner::assert_same(
            [['field' => 'has_project', 'value' => '']], BHCRM_Segments::sanitize_conditions([['field' => 'has_project', 'value' => '']]),
            'sanitize_conditions(): has_project with NO value is correctly kept — it is the one field that needs no value (a regression treating it like every other field would silently drop every has_project condition)'
        );

        $rows[] = OUS_TestRunner::assert_same(
            [], BHCRM_Segments::sanitize_conditions([['value' => 'vip']]),
            'sanitize_conditions(): a condition missing "field" entirely is dropped, not treated as an empty-string field match'
        );

        $rows[] = OUS_TestRunner::assert_same(
            [], BHCRM_Segments::sanitize_conditions('not-an-array'),
            'sanitize_conditions(): a completely malformed (non-array) input degrades to an empty condition set rather than throwing'
        );

        return $rows;
    }

    /* ---------- BHCRM_Export::csv_safe() ---------- */

    private static function run_csv_safe_tests() {
        if (!class_exists('BHCRM_Export')) return [];
        $rows = [];
        foreach (['=cmd', '+1', '-1', '@SUM(A1)'] as $formula) {
            $rows[] = OUS_TestRunner::assert_same(
                "'" . $formula, BHCRM_Export::csv_safe($formula),
                "csv_safe(): a value starting with '" . $formula[0] . "' gets a defusing leading apostrophe (CSV-injection guard)"
            );
        }
        $rows[] = OUS_TestRunner::assert_same(
            'Ordinary Name', BHCRM_Export::csv_safe('Ordinary Name'),
            'csv_safe(): an ordinary value is passed through unchanged'
        );
        $rows[] = OUS_TestRunner::assert_same(
            '', BHCRM_Export::csv_safe(''),
            'csv_safe(): an empty string does not throw on the $value[0] access and returns empty'
        );
        return $rows;
    }

    /* ---------- BHCRM_Subtasks tree helpers — private, via Reflection ---------- */

    private static function run_subtasks_tree_tests() {
        if (!class_exists('BHCRM_Subtasks')) return [];
        $rows = [];

        $find_node = new ReflectionMethod('BHCRM_Subtasks', 'find_node');
        $children_at = new ReflectionMethod('BHCRM_Subtasks', 'children_at');
        $total_count = new ReflectionMethod('BHCRM_Subtasks', 'total_node_count');

        $tree = [
            ['attrs' => ['uid' => 'a'], 'children' => [
                ['attrs' => ['uid' => 'a1'], 'children' => []],
                ['attrs' => ['uid' => 'a2'], 'children' => [
                    ['attrs' => ['uid' => 'a2i'], 'children' => []],
                ]],
            ]],
            ['attrs' => ['uid' => 'b'], 'children' => []],
        ];

        $found = &$find_node->invokeArgs(null, [&$tree, ['a', 'a2', 'a2i']]);
        $rows[] = OUS_TestRunner::assert_same(
            'a2i', $found['attrs']['uid'] ?? null,
            'find_node(): locates a node 3 levels deep by its exact uid path'
        );

        $missing = &$find_node->invokeArgs(null, [&$tree, ['a', 'nonexistent']]);
        $rows[] = OUS_TestRunner::assert_true(
            $missing === null,
            'find_node(): a path referencing a uid that does not exist (e.g. a deleted card) returns null rather than a wrong/partial node'
        );

        $children = &$children_at->invokeArgs(null, [&$tree, ['a']]);
        $rows[] = OUS_TestRunner::assert_same(
            2, count($children),
            'children_at(): returns the real children array (by reference) for an existing path'
        );

        $empty_children = &$children_at->invokeArgs(null, [&$tree, ['b', 'nonexistent']]);
        $rows[] = OUS_TestRunner::assert_same(
            0, count($empty_children),
            'children_at(): a path through a non-existent intermediate node returns an empty array, not a fatal error or a reference into the wrong node'
        );

        $rows[] = OUS_TestRunner::assert_same(
            5, $total_count->invoke(null, $tree),
            'total_node_count(): counts every node across every nesting level (a=1 + a1=1 + a2=1 + a2i=1 + b=1 = 5), catching an off-by-one or a level skipped during recursion'
        );

        $rows[] = OUS_TestRunner::assert_same(
            0, $total_count->invoke(null, []),
            'total_node_count(): an empty tree counts as 0, not an error'
        );

        return $rows;
    }
}
