<?php
if (!defined('ABSPATH')) exit;

/**
 * Reads/writes bhc_progress (see class-activator.php). A plain content
 * step (text/image) completes on an explicit "mark complete" click from
 * the front end; a quiz step only completes via a submitted attempt,
 * and only counts as "passed" if the score clears the step's own
 * passing_score. Also owns enrollment recording (bhc_enrollments — see
 * class-gate.php's drip-scheduling use of it) and course-completion
 * detection (bhc_completions + the bhc_course_completed action).
 */
class BHC_Progress {
    public static function init() {
        // Nothing to hook here beyond the two AJAX actions registered
        // in the main bootstrap file — kept as an init() entry point
        // anyway for consistency with every other class in this
        // ecosystem.
    }

    private static function table() {
        global $wpdb;
        return $wpdb->prefix . 'bhc_progress';
    }

    public static function step_status($user_id, $lesson_id, $step_index) {
        global $wpdb;
        if (!$user_id) return null;
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . self::table() . " WHERE user_id = %d AND lesson_id = %d AND step_index = %d",
            $user_id, $lesson_id, $step_index
        ), ARRAY_A);
    }

    public static function is_step_complete($user_id, $lesson_id, $step_index) {
        $row = self::step_status($user_id, $lesson_id, $step_index);
        // A quiz step only counts as "complete" (i.e. the walker can
        // advance past it) once passed — a failed attempt still writes
        // a row (so attempts/score are tracked), but shouldn't read as
        // done. A non-quiz row has passed = NULL, which the ?? true
        // treats as "nothing to pass, so complete on write" — unchanged
        // behavior from before max_attempts existed.
        if (!$row) return false;
        return $row['passed'] === null ? true : (bool) $row['passed'];
    }

    // Highest step index a user has actually cleared in this lesson,
    // i.e. how far they can navigate to (next-uncompleted-step gating
    // lives in class-render.php, not here — this is just the data).
    // Only counts steps that are genuinely done per is_step_complete()'s
    // rule above (a failed, attempts-exhausted quiz never counts).
    public static function completed_steps($user_id, $lesson_id) {
        global $wpdb;
        if (!$user_id) return [];
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT step_index, passed FROM " . self::table() . " WHERE user_id = %d AND lesson_id = %d ORDER BY step_index",
            $user_id, $lesson_id
        ), ARRAY_A);
        $done = [];
        foreach ($rows as $row) {
            if ($row['passed'] === null || (int) $row['passed'] === 1) $done[] = (int) $row['step_index'];
        }
        return $done;
    }

    public static function attempts($user_id, $lesson_id, $step_index) {
        $row = self::step_status($user_id, $lesson_id, $step_index);
        return $row ? (int) $row['attempts'] : 0;
    }

    // $answers_json: pre-encoded JSON string (or null), the per-question
    // snapshot from BHC_Steps::score_quiz()'s 'questions' detail — see
    // ajax_submit_quiz() below for where it's assembled. Same conditional-
    // NULL-placeholder technique the score/passed QA fix already
    // established (see the comment below): a plain text/image step, or a
    // quiz row written before this column existed, gets a real SQL NULL,
    // never a stringified 'null'/empty string.
    public static function mark_step_complete($user_id, $lesson_id, $step_index, $score = null, $passed = null, $answers_json = null) {
        global $wpdb;
        // QA fix: $wpdb->prepare() has no NULL passthrough for scalar
        // placeholders — a PHP null bound through %s/%d is cast to ''/0
        // before the query runs, so the old version here was writing
        // score = 0 / passed = 0 for every plain text/image step instead
        // of a real SQL NULL. is_step_complete()/completed_steps() both
        // explicitly test `$row['passed'] === null` to detect "non-quiz
        // step, complete once a row exists at all" — with passed coming
        // back as "0" instead of NULL, that check always failed, so
        // every non-quiz step permanently read as incomplete. Building
        // the column list/placeholders conditionally keeps a real SQL
        // NULL for the non-quiz case while still using %d for real values.
        $score_sql   = $score === null ? 'NULL' : '%d';
        $passed_sql  = $passed === null ? 'NULL' : '%d';
        $answers_sql = $answers_json === null ? 'NULL' : '%s';
        $values = [$user_id, $lesson_id, $step_index];
        if ($score !== null) $values[] = (int) $score;
        if ($passed !== null) $values[] = (int) $passed;
        if ($answers_json !== null) $values[] = (string) $answers_json;

        $result = $wpdb->query($wpdb->prepare(
            "INSERT INTO " . self::table() . " (user_id, lesson_id, step_index, score, passed, attempts, answers)
             VALUES (%d, %d, %d, $score_sql, $passed_sql, 1, $answers_sql)
             ON DUPLICATE KEY UPDATE completed_at = CURRENT_TIMESTAMP, score = VALUES(score), passed = VALUES(passed), answers = VALUES(answers), attempts = attempts + 1",
            $values
        ));
        if ($result === false && class_exists('OUS_DebugLog')) {
            // First OUS_DebugLog call anywhere in bh-courses — previously
            // a failed write here meant the AJAX handler still reported
            // "step complete" to the student (see class-progress.php's
            // ajax_submit_quiz()/ajax_mark_complete(), which don't
            // separately check this method's success), so progress could
            // silently not persist with zero trace anywhere.
            OUS_DebugLog::log('error', 'mark_step_complete() DB write failed — student will still be told the step completed.', [
                'user_id' => $user_id, 'lesson_id' => $lesson_id, 'step_index' => $step_index, 'db_error' => $wpdb->last_error,
            ], 'BH Courses Progress');
        }

        if ($passed === null || $passed) {
            self::maybe_fire_course_completed($user_id, BHC_PostTypes::course_for_lesson($lesson_id));
        }
    }

    // The stored per-question snapshot for a quiz step, decoded — null if
    // this isn't a (scored, answers-bearing) quiz row, or predates the
    // answers column. Used by class-render.php to render a static review
    // of a passed quiz instead of re-deriving anything from the current
    // (possibly since-edited) _bhc_steps content — see the answers
    // column's own comment in class-activator.php for why that matters.
    public static function stored_answers($user_id, $lesson_id, $step_index) {
        $row = self::step_status($user_id, $lesson_id, $step_index);
        if (!$row || empty($row['answers'])) return null;
        $decoded = json_decode($row['answers'], true);
        return is_array($decoded) ? $decoded : null;
    }

    // Percent of a whole COURSE a user has completed — steps across
    // every lesson in the course's own order, not just one lesson.
    public static function course_percent($user_id, $course_id) {
        if (!$user_id) return 0;
        $lesson_ids = BHC_PostTypes::lesson_order($course_id);
        if (!$lesson_ids) return 0;

        $total = 0;
        $done = 0;
        foreach ($lesson_ids as $lesson_id) {
            $step_count = BHC_Steps::count($lesson_id);
            $total += $step_count;
            $done += count(self::completed_steps($user_id, $lesson_id));
        }
        return $total ? (int) round(($done / $total) * 100) : 0;
    }

    // The lesson-level sibling of class-render.php's own step-level
    // "first not-yet-completed" logic (render_lesson_steps()'s
    // $start_index calc) — same idea, one level up, for the course-page
    // "Continue" CTA. Skips lessons that aren't published, aren't open
    // yet (drip-locked), or have no steps at all (nothing to resume
    // into). Returns null if every open lesson is fully done — the
    // caller (class-render.php) treats that as "show a Review/Complete
    // state instead."
    public static function first_incomplete_lesson($user_id, $course_id) {
        $lesson_ids = BHC_PostTypes::lesson_order($course_id);
        foreach ($lesson_ids as $lesson_id) {
            if (get_post_status($lesson_id) !== 'publish') continue;
            if (class_exists('BHC_Gate') && !BHC_Gate::lesson_is_open($user_id, $lesson_id)) continue;
            $step_count = BHC_Steps::count($lesson_id);
            if (!$step_count) continue;
            $done_count = $user_id ? count(self::completed_steps($user_id, $lesson_id)) : 0;
            if ($done_count < $step_count) return $lesson_id;
        }
        return null;
    }

    /* ---------------- enrollment (drip scheduling's clock-start) ---------------- */

    // Called once access is confirmed (class-render.php, on viewing the
    // course or a lesson in it) — cheap no-op on every repeat visit
    // thanks to INSERT IGNORE, so callers don't need their own "have I
    // already enrolled this person" check.
    public static function enroll_if_needed($user_id, $course_id) {
        if (!$user_id || !$course_id) return;
        global $wpdb;
        $wpdb->query($wpdb->prepare(
            "INSERT IGNORE INTO {$wpdb->prefix}bhc_enrollments (user_id, course_id) VALUES (%d, %d)",
            $user_id, $course_id
        ));
    }

    public static function enrolled_at($user_id, $course_id) {
        global $wpdb;
        return $wpdb->get_var($wpdb->prepare(
            "SELECT enrolled_at FROM {$wpdb->prefix}bhc_enrollments WHERE user_id = %d AND course_id = %d",
            $user_id, $course_id
        ));
    }

    // The catalog's "popular" sort signal (QUIZ-AND-CATALOG-DESIGN-PLAN.md
    // Part 2.3) — a real, deduped, non-gameable enrollment count read
    // straight off bhc_enrollments' own UNIQUE KEY (user_id, course_id),
    // never a denormalized counter column that could drift out of sync.
    // Returns course_id => count for every course with at least one
    // enrollment; a course with zero simply isn't in the returned array
    // (callers treat a missing key as 0).
    public static function enrollment_counts() {
        global $wpdb;
        $rows = $wpdb->get_results(
            "SELECT course_id, COUNT(*) AS c FROM {$wpdb->prefix}bhc_enrollments GROUP BY course_id",
            ARRAY_A
        );
        $counts = [];
        foreach ($rows as $row) $counts[(int) $row['course_id']] = (int) $row['c'];
        return $counts;
    }

    /* ---------------- completion (bhc_course_completed) ---------------- */

    // Fires 'bhc_course_completed' ($user_id, $course_id) the first
    // time — and only the first time — a student clears 100% of a
    // course. Dedup is enforced by bhc_completions' own UNIQUE KEY (an
    // atomic INSERT that either succeeds once or silently no-ops on
    // every later call), not by an application-level "have I fired this
    // already" check, so a race between two nearly-simultaneous last
    // steps can't double-fire it either.
    private static function maybe_fire_course_completed($user_id, $course_id) {
        if (!$user_id || !$course_id) return;
        if (self::course_percent($user_id, $course_id) < 100) return;

        global $wpdb;
        $wpdb->query($wpdb->prepare(
            "INSERT IGNORE INTO {$wpdb->prefix}bhc_completions (user_id, course_id) VALUES (%d, %d)",
            $user_id, $course_id
        ));
        if ((int) $wpdb->rows_affected === 1) {
            do_action('bhc_course_completed', $user_id, $course_id);
        }
    }

    public static function is_course_completed($user_id, $course_id) {
        global $wpdb;
        return (bool) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}bhc_completions WHERE user_id = %d AND course_id = %d",
            $user_id, $course_id
        ));
    }

    /* ---------------- AJAX handlers (logged-in students) ---------------- */

    public static function ajax_mark_complete() {
        check_ajax_referer('bhc_progress', 'nonce');
        $user_id = get_current_user_id();
        if (!$user_id) wp_send_json_error(['message' => 'Log in required.'], 401);

        $lesson_id = (int) ($_POST['lesson_id'] ?? 0);
        $step_index = (int) ($_POST['step_index'] ?? -1);
        $step = BHC_Steps::get_step($lesson_id, $step_index);
        if (!$step || $step['type'] === 'quiz') {
            wp_send_json_error(['message' => 'Invalid step, or this step requires quiz submission instead.'], 400);
        }
        if (!BHC_Gate::user_can_access_lesson($user_id, $lesson_id)) {
            wp_send_json_error(['message' => 'Access required.'], 403);
        }

        self::mark_step_complete($user_id, $lesson_id, $step_index);
        wp_send_json_success(['step_index' => $step_index]);
    }

    public static function ajax_submit_quiz() {
        check_ajax_referer('bhc_progress', 'nonce');
        $user_id = get_current_user_id();
        if (!$user_id) wp_send_json_error(['message' => 'Log in required.'], 401);

        $lesson_id = (int) ($_POST['lesson_id'] ?? 0);
        $step_index = (int) ($_POST['step_index'] ?? -1);
        $step = BHC_Steps::get_step($lesson_id, $step_index);
        if (!$step || $step['type'] !== 'quiz') {
            wp_send_json_error(['message' => 'Invalid quiz step.'], 400);
        }
        if (!BHC_Gate::user_can_access_lesson($user_id, $lesson_id)) {
            wp_send_json_error(['message' => 'Access required.'], 403);
        }

        $max_attempts = (int) ($step['max_attempts'] ?? 0);
        $existing = self::step_status($user_id, $lesson_id, $step_index);
        $already_passed = $existing && (int) $existing['passed'] === 1;
        $attempts_so_far = $existing ? (int) $existing['attempts'] : 0;

        if (!$already_passed && $max_attempts > 0 && $attempts_so_far >= $max_attempts) {
            wp_send_json_error([
                'message' => "No attempts remaining ($max_attempts allowed).",
                'attempts_used' => $attempts_so_far, 'max_attempts' => $max_attempts,
            ], 403);
        }

        // QA fix: a step that's already passed must never be rescored —
        // the old code only used $already_passed to skip the attempts-
        // exhausted check above, then fell through to score_quiz() and
        // mark_step_complete() regardless, which could overwrite a
        // passing result with a failing one on a resubmit/replayed POST
        // (the front end disables the resubmit UI, but that's not a
        // server-side guarantee). Once passed, stay passed.
        if ($already_passed) {
            // Return the stored snapshot (if this row predates the
            // answers column, stored_answers() is simply null and the
            // front end falls back to the aggregate-only display it
            // already had) so a resubmit against an already-passed quiz
            // — which the disabled UI shouldn't normally trigger, but a
            // replayed POST could — still gets the same rich response a
            // fresh pass would, rather than a degraded one.
            $snapshot = self::stored_answers($user_id, $lesson_id, $step_index);
            wp_send_json_success([
                'score' => (int) $existing['score'], 'passed' => true,
                'total' => count($step['questions'] ?? []), 'correct' => null,
                'questions' => $snapshot['questions'] ?? null,
                'attempts_used' => $attempts_so_far, 'max_attempts' => $max_attempts,
                'attempts_remaining' => $max_attempts > 0 ? max(0, $max_attempts - $attempts_so_far) : null,
                'already_passed' => true,
            ]);
        }

        $raw_answers = (array) ($_POST['answers'] ?? []);
        $answers = [];
        foreach ($raw_answers as $q_index => $choice_index) {
            $answers[(int) $q_index] = (int) $choice_index;
        }

        $result = BHC_Steps::score_quiz($step, $answers);

        // Snapshot per QUIZ-AND-CATALOG-DESIGN-PLAN.md Part 1.3: self-
        // contained (question text/choices/correct_index, not just the
        // chosen index), so a later edit to this quiz can never corrupt
        // what this review shows. score/passed/passing_score duplicated
        // into the blob too, so a review render is one row read, not a
        // join against the step's own current (possibly different) config.
        $answers_json = wp_json_encode([
            'score' => $result['score'],
            'passed' => $result['passed'],
            'passing_score' => (int) ($step['passing_score'] ?? 70),
            'questions' => $result['questions'],
        ]);
        self::mark_step_complete($user_id, $lesson_id, $step_index, $result['score'], $result['passed'], $answers_json);

        $result['attempts_used'] = $attempts_so_far + 1;
        $result['max_attempts'] = $max_attempts;
        $result['attempts_remaining'] = $max_attempts > 0 ? max(0, $max_attempts - $result['attempts_used']) : null;
        wp_send_json_success($result);
    }
}
