<?php
if (!defined('ABSPATH')) exit;

/**
 * Extracted from the old monolithic class-render.php (SRP QA pass,
 * bh-courses 0.4.8) — see class-render-catalog.php's own docblock for
 * the full "why three classes" reasoning; this is a pure move, not a
 * rewrite. This class owns exactly one page: the [bh_course] shortcode /
 * single course detail view (cover, header, description, terms,
 * enrollment CTA, lesson list or locked syllabus preview).
 *
 * render_continue_cta() is PUBLIC here (it used to be a private helper
 * shared within one file) because BHC_Render_Catalog's own course-card
 * rendering also needs the exact same "where should this student go
 * next" decision — both call sites need the identical logic, so it lives
 * on whichever of the two classes is the more natural owner (the course
 * page itself) and the catalog calls across to it, rather than either
 * duplicating the logic or inventing a third shared-helper class for one
 * method.
 */
class BHC_Render_Course {
    private static function render_course_header(int $course_id, int $uid, bool $locked): string {
        $difficulty_label = BHC_PostTypes::difficulty_label($course_id);
        $instructor = BHC_PostTypes::instructor($course_id);
        $lesson_count = BHC_PostTypes::lesson_count($course_id);
        $duration = BHC_PostTypes::duration_note($course_id);
        $categories = get_the_terms($course_id, 'bhc_course_category');
        $topics = get_the_terms($course_id, 'bhc_course_topic');

        $has_cover = has_post_thumbnail($course_id);

        ob_start();
        echo '<div class="bhc-course-header">';
        // Real live-caught inconsistency (2026-08): this used to skip the
        // hero entirely with no cover set ("obvious-or-gone"), falling
        // back to plain stacked text — but that meant the exact same
        // course looked like two different products depending on
        // whether an image happened to be uploaded yet, and a course
        // with no cover got a visibly less finished page than the
        // catalog card that led here (which always gets a hero image
        // slot as of the same pass — see .bhc-card-thumb-placeholder).
        // Every course page now gets the hero treatment; a missing cover
        // gets the same gradient+waveform placeholder the catalog uses
        // instead of silently degrading to a plainer layout.
        echo '<div class="bhc-course-hero' . ($has_cover ? '' : ' bhc-course-hero-placeholder') . '">';
        if ($has_cover) echo get_the_post_thumbnail($course_id, 'large');
        echo '<div class="bhc-course-hero-scrim"><div class="bhc-course-hero-content">';
        echo '<h1 class="bhc-course-title">' . esc_html(get_the_title($course_id)) . '</h1>';
        if ($difficulty_label) echo '<span class="bh-badge bhc-badge bhc-badge-difficulty bhc-difficulty-' . esc_attr(BHC_PostTypes::difficulty($course_id)) . '">' . esc_html($difficulty_label) . '</span>';
        echo '</div></div>';
        echo '</div>';

        // Instructor presence pulled forward into its own row (a real
        // "who's teaching you this" moment) instead of one more compact
        // badge buried in the meta line — only when there's an actual
        // instructor to show (obvious-or-gone).
        if ($instructor) {
            echo '<div class="bhc-course-instructor-row">' . get_avatar($instructor->ID, 48) . '<div><span class="bhc-course-instructor-label">Taught by</span><span class="bhc-course-instructor-name">' . esc_html($instructor->display_name ?: $instructor->user_login) . '</span></div></div>';
        }

        // Difficulty badge now always lives in the hero overlay above
        // (every course gets a hero, real cover or placeholder), so it's
        // no longer duplicated here for the no-cover case.
        echo '<div class="bhc-course-meta">';
        echo '<span>' . (int) $lesson_count . ' lesson' . ($lesson_count === 1 ? '' : 's') . '</span>';
        if ($duration) echo '<span>' . esc_html($duration) . '</span>';
        if (class_exists('BHC_Reviews')) {
            $rating = BHC_Reviews::average_rating($course_id);
            if ($rating['count'] > 0) {
                echo '<span class="bhc-course-rating">' . self::render_stars($rating['average']) . ' <span class="bhc-rating-number">' . esc_html((string) $rating['average']) . '</span> <span class="bhc-rating-count">(' . (int) $rating['count'] . ' review' . ($rating['count'] === 1 ? '' : 's') . ')</span></span>';
            }
        }
        echo '</div>';

        if (!empty($categories) && !is_wp_error($categories)) {
            echo '<div class="bhc-course-terms">';
            foreach ($categories as $t) echo '<span class="bhc-term bhc-term-category">' . esc_html($t->name) . '</span>';
            if (!empty($topics) && !is_wp_error($topics)) {
                foreach ($topics as $t) echo '<span class="bhc-term bhc-term-topic">' . esc_html($t->name) . '</span>';
            }
            echo '</div>';
        }

        $content = get_post_field('post_content', $course_id);
        if ($content) echo '<div class="bhc-course-description">' . apply_filters('the_content', $content) . '</div>';

        if ($uid && !$locked) {
            $percent = BHC_Progress::course_percent($uid, $course_id);
            $cta = self::render_continue_cta($uid, $course_id, $percent);
            if ($cta) echo '<div class="bhc-course-header-cta">' . $cta . '</div>';
            // The flat "Download certificate" link that used to live here
            // is now the dedicated completion screen (render_completion_screen()
            // below, called from render_course()) — a real payoff moment
            // instead of a bare afterthought link.
        }
        echo '</div>';
        return ob_get_clean();
    }

    /** @param mixed $atts */
    public static function render_course($atts): string {
        $course_id = (int) ($atts['id'] ?? get_the_ID());
        if (!$course_id || get_post_type($course_id) !== 'bh_course') return '';

        if (class_exists('BH_SEO')) {
            $instructor = BHC_PostTypes::instructor($course_id);
            BH_SEO::set_page_data([
                'title' => get_the_title($course_id) . ' — ' . get_bloginfo('name'),
                'description' => wp_strip_all_tags(get_post_field('post_content', $course_id)) ?: (get_the_title($course_id) . ', a course on ' . get_bloginfo('name')),
                'url' => get_permalink($course_id),
                'image' => has_post_thumbnail($course_id) ? get_the_post_thumbnail_url($course_id, 'large') : null,
                'type' => 'website',
                'schema' => [
                    '@context' => 'https://schema.org',
                    '@type' => 'Course',
                    'name' => get_the_title($course_id),
                    'description' => wp_strip_all_tags(get_post_field('post_content', $course_id)) ?: null,
                    'url' => get_permalink($course_id),
                    'image' => has_post_thumbnail($course_id) ? get_the_post_thumbnail_url($course_id, 'large') : null,
                    'provider' => [
                        '@type' => 'Organization',
                        'name' => get_bloginfo('name'),
                        'sameAs' => home_url(),
                    ],
                    'hasCourseInstance' => $instructor ? [
                        '@type' => 'CourseInstance',
                        'courseMode' => 'online',
                        'instructor' => [
                            '@type' => 'Person',
                            'name' => $instructor->display_name ?: $instructor->user_login,
                        ],
                    ] : null,
                ],
            ]);
        }

        $uid = get_current_user_id();
        $locked = !BHC_Gate::user_can_access_course($uid, $course_id);
        $lesson_ids = BHC_PostTypes::lesson_order($course_id);

        // The moment a logged-in student is confirmed to have real
        // access, start their drip-scheduling clock for this course —
        // see BHC_Progress::enroll_if_needed()'s docblock for why this
        // is the one place that's safe/correct to call it from (access
        // just got confirmed, not merely attempted). $just_enrolled is
        // true only on this exact request, the real first-ever
        // enrollment — used below to show a one-time orientation moment
        // instead of dropping straight into the ordinary progress/lesson-
        // list view a returning student sees.
        $just_enrolled = false;
        if ($uid && !$locked) $just_enrolled = BHC_Progress::enroll_if_needed($uid, $course_id);

        ob_start();
        echo '<div class="bhc-course-view">';
        // Detail-page header (QUIZ-AND-CATALOG-DESIGN-PLAN.md Section
        // 2.7): wraps the existing lesson-list output below rather than
        // replacing it — full cover, description, instructor,
        // difficulty, duration, category/topic terms, enrollment CTA.
        // Ratings/reviews now live in BHC_Reviews (class-reviews.php).
        echo self::render_course_header($course_id, $uid, $locked);
        if ($locked) {
            echo BHC_Gate::render_paywall_notice($course_id);
            // Even locked, a prospective student can see what they'd be
            // signing up for — a syllabus of lesson TITLES only (no
            // content, no permalink), same "tease, don't leak" posture
            // the drip-lock notice already takes for individual lessons.
            if ($lesson_ids) {
                echo '<div class="bhc-syllabus-preview"><h4>What you\'ll learn</h4><ol class="bhc-lesson-list bhc-lesson-list-preview">';
                foreach ($lesson_ids as $lesson_id) {
                    if (get_post_status($lesson_id) !== 'publish') continue;
                    echo '<li><span>' . esc_html(get_the_title($lesson_id)) . '</span></li>';
                }
                echo '</ol></div>';
            }
        } else {
            // First-ever enrollment: a one-time "here's what you're
            // about to learn" moment instead of dropping straight into
            // the ordinary progress/lesson-list view — sets real
            // expectations before the day-to-day lesson queue begins,
            // same Disneyland-queue framing as the rest of this pass.
            // Bug fix (2026-07-25 audit): this used to render ALONGSIDE
            // the ordinary progress bar + full lesson list below, not
            // "instead of" as the comment above claims — the syllabus
            // showed twice on one page. $just_enrolled now gates the
            // rest of this branch too (see the matching check below).
            if ($just_enrolled) echo self::render_orientation_screen($uid, $course_id, $lesson_ids);

            // The real payoff moment — a dedicated completion screen
            // (stats, certificate, share card, next steps) once this
            // student has actually finished, in place of the flat
            // "Download certificate" link this section used to carry.
            // Placed above the progress bar/lesson list rather than
            // below: the completion moment is the headline once it's
            // true, not a footnote after a now-100%-full progress bar.
            if ($uid) echo self::render_completion_screen($uid, $course_id);

            // Enrollment/continue CTA now lives in render_course_header()
            // above (shown for every locked/unlocked state consistently)
            // — not duplicated here anymore.
            // Suppressed on the orientation screen itself ($just_enrolled):
            // the orientation card already shows its own syllabus <ol> and
            // a "Start" CTA — showing the ordinary progress bar + full
            // lesson list right underneath duplicated that same content
            // on one page. This block now renders on every visit AFTER
            // the one-time orientation moment, same as before.
            if (!$just_enrolled) {
                if ($uid) {
                    $percent = BHC_Progress::course_percent($uid, $course_id);
                    echo '<div class="bhc-progress-bar bhc-progress-bar-large"><div class="bhc-progress-fill" style="width:' . (int) $percent . '%"></div></div><p class="bhc-progress-label">' . (int) $percent . '% complete</p>';
                    // Mastery signal — only ever shown once a real quiz has
                    // actually been scored (course_quiz_average() returns
                    // null, not 0, until then), never a "0%" placeholder
                    // nagging a student who hasn't reached a quiz yet.
                    $quiz_average = BHC_Progress::course_quiz_average($uid, $course_id);
                    if ($quiz_average !== null) {
                        echo '<p class="bhc-mastery-label">Mastery: ' . (int) $quiz_average . '%</p>';
                    }
                }
                echo self::render_grouped_lesson_list($course_id, $uid, null, false);
            }
        }
        if (!$locked && class_exists('BHC_Leaderboard')) echo BHC_Leaderboard::render($course_id);
        if (!$locked && class_exists('BHC_Reviews')) echo self::render_reviews_section($course_id, $uid);
        echo '</div>';
        return ob_get_clean();
    }

    // Whole-star glyphs, rounded to the nearest star — simple on
    // purpose (matches the admin moderation table's own str_repeat
    // approach) rather than half-star rendering, which would need a
    // second glyph/SVG this codebase doesn't otherwise use anywhere.
    private static function render_stars(float $rating): string {
        $full = (int) round($rating);
        $full = max(0, min(5, $full));
        return '<span class="bhc-stars" aria-hidden="true">' . str_repeat('&#9733;', $full) . str_repeat('&#9734;', 5 - $full) . '</span>';
    }

    // Reviews list (approved only — a pending/rejected review is only
    // ever visible to the student who wrote it, via the form state
    // below) + the submission/edit form. Eligibility is ENROLLMENT, not
    // completion — locked-out visitors never see this section at all
    // (the caller already gates on !$locked).
    private static function render_reviews_section(int $course_id, int $uid): string {
        ob_start();
        echo '<div class="bhc-reviews-section" id="bhc-reviews">';
        echo '<h2>Reviews</h2>';

        $reviews = BHC_Reviews::reviews_for_course($course_id, 'approved');
        if (!$reviews) {
            echo '<p class="description">No reviews yet.</p>';
        } else {
            echo '<div class="bhc-review-list">';
            foreach ($reviews as $review) {
                $reviewer = get_userdata((int) $review['user_id']);
                $name = $reviewer ? ($reviewer->display_name ?: $reviewer->user_login) : 'A student';
                echo '<div class="bhc-review">';
                echo '<div class="bhc-review-head">' . self::render_stars((int) $review['rating']) . ' <strong>' . esc_html($name) . '</strong>';
                echo $review['completed_at_review']
                    ? ' <span class="bh-badge bhc-review-badge bhc-review-badge-completed">Completed the course</span>'
                    : ' <span class="bh-badge bhc-review-badge bhc-review-badge-enrolled">Enrolled</span>';
                echo '</div>';
                if ($review['body']) echo '<p class="bhc-review-body">' . esc_html($review['body']) . '</p>';
                echo '<p class="bhc-review-date">' . esc_html(date_i18n(get_option('date_format'), strtotime($review['created_at']))) . '</p>';
                echo '</div>';
            }
            echo '</div>';
        }

        if ($uid && BHC_Progress::enrolled_at($uid, $course_id)) {
            $mine = BHC_Reviews::user_review($uid, $course_id);
            echo '<div class="bhc-review-form-wrap">';
            if ($mine) {
                if ($mine['status'] === 'pending') {
                    echo '<p class="bhc-review-status-note">Your review is awaiting approval.</p>';
                } elseif ($mine['status'] === 'rejected') {
                    echo '<p class="bhc-review-status-note bhc-review-status-rejected">Your review wasn\'t approved. You can edit and resubmit it below.</p>';
                } else {
                    echo '<p class="bhc-review-status-note">Your review is live below — thanks for sharing it! You can still edit it any time.</p>';
                }
            }
            echo '<form class="bhc-review-form" data-course-id="' . (int) $course_id . '">';
            echo '<fieldset><legend>' . ($mine ? 'Edit your review' : 'Leave a review') . '</legend>';
            echo '<div class="bhc-review-star-picker" role="radiogroup" aria-label="Rating">';
            for ($i = 5; $i >= 1; $i--) {
                $checked = $mine && (int) $mine['rating'] === $i;
                echo '<label class="bhc-review-star-choice"><input type="radio" name="rating" value="' . $i . '"' . ($checked ? ' checked' : '') . ' required> <span aria-hidden="true">&#9733;</span><span class="screen-reader-text">' . $i . ' star' . ($i === 1 ? '' : 's') . '</span></label>';
            }
            echo '</div>';
            echo '<textarea class="bhc-review-textarea" placeholder="What did you think? (optional)" rows="3">' . esc_textarea($mine['body'] ?? '') . '</textarea>';
            echo '<button type="submit" class="bhc-btn">' . ($mine ? 'Update review' : 'Submit review') . '</button>';
            echo '<div class="bhc-review-form-result" role="status" aria-live="polite"></div>';
            echo '</fieldset></form>';
            echo '</div>';
        }

        echo '</div>';
        return ob_get_clean();
    }

    // Shared between the course page's own lesson list (unlocked branch
    // above) and BHC_Render_Lesson's per-lesson view — a student inside a
    // lesson previously had no way to see the rest of the course or jump
    // between lessons without going back to the course page first.
    // $current_lesson_id highlights the lesson currently open; null on
    // the course page itself (nothing is "current" there).
    public static function render_lesson_sidebar(int $course_id, int $uid, ?int $current_lesson_id = null): string {
        $lesson_ids = BHC_PostTypes::lesson_order($course_id);
        if (!$lesson_ids) return '';
        $percent = $uid ? BHC_Progress::course_percent($uid, $course_id) : 0;

        ob_start();
        echo '<nav class="bhc-course-sidebar" aria-label="Course lessons">';
        echo '<a class="bhc-sidebar-course-link" href="' . esc_url(get_permalink($course_id)) . '">' . esc_html(get_the_title($course_id)) . '</a>';
        if ($uid) {
            echo '<div class="bhc-progress-bar"><div class="bhc-progress-fill" style="width:' . (int) $percent . '%"></div></div><p class="bhc-progress-label">' . (int) $percent . '% complete</p>';
        }
        echo self::render_grouped_lesson_list($course_id, $uid, $current_lesson_id, true);
        echo '</nav>';
        return ob_get_clean();
    }

    // One lesson <li>'s markup, shared by both list modes below — the
    // sidebar and course-page lists previously duplicated this near-
    // identically, which is exactly how the sidebar's aria-current/
    // current-lesson highlighting had drifted from the course page's
    // drip-notice/step-progress display instead of just being the two
    // real differences they are.
    /** @return array{html:string, complete:bool, is_current:bool} */
    private static function render_lesson_li(int $lesson_id, int $uid, ?int $current_lesson_id, bool $is_sidebar): array {
        $open = BHC_Gate::lesson_is_open($uid, $lesson_id);
        $step_count = BHC_Steps::count($lesson_id);
        $done_count = $uid ? count(BHC_Progress::completed_steps($uid, $lesson_id)) : 0;
        $complete = $step_count > 0 && $done_count >= $step_count;
        $is_current = $is_sidebar && $current_lesson_id && (int) $lesson_id === (int) $current_lesson_id;
        $classes = trim(($complete ? 'bhc-lesson-done' : '') . (!$open ? ' bhc-lesson-locked' : '') . ($is_current ? ' bhc-lesson-current' : ''));

        $html = '<li class="' . $classes . '">';
        if ($open) {
            $html .= '<a href="' . esc_url(get_permalink($lesson_id)) . '"' . ($is_current ? ' aria-current="page"' : '') . '>' . esc_html(get_the_title($lesson_id)) . '</a>';
        } else {
            $html .= '<span>' . esc_html(get_the_title($lesson_id)) . '</span> <span class="bhc-drip-notice">&#128274;'
                . ($is_sidebar ? '' : ' ' . BHC_Gate::drip_notice($uid, $lesson_id)) . '</span>';
        }
        if (!$is_sidebar && $open && $uid && $step_count) {
            $html .= ' <span class="bhc-lesson-progress">(' . (int) $done_count . '/' . (int) $step_count . ')</span>';
        }
        if ($complete) $html .= ' <span class="bhc-check">&#10003;</span>';
        $html .= '</li>';
        return ['html' => $html, 'complete' => $complete, 'is_current' => $is_current];
    }

    // Groups from BHC_PostTypes::grouped_lesson_order() render as
    // collapsible <details> sections when a group has a module title;
    // a blank-titled group's lesson renders as a bare <li>, exactly the
    // pre-module-feature markup, so an ungrouped course looks unchanged.
    // A section starts open unless every lesson inside it is already
    // complete (and doesn't contain the current lesson) — finished
    // modules collapse out of the way, current/upcoming ones stay
    // visible, matching how the stepper already treats past vs. current
    // steps.
    private static function render_grouped_lesson_list(int $course_id, int $uid, ?int $current_lesson_id, bool $is_sidebar): string {
        $list_class = $is_sidebar ? 'bhc-lesson-list bhc-sidebar-lesson-list' : 'bhc-lesson-list';
        $out = '<ol class="' . $list_class . '">';
        foreach (BHC_PostTypes::grouped_lesson_order($course_id) as $group) {
            $items = '';
            $group_complete = true;
            $group_has_current = false;
            foreach ($group['lesson_ids'] as $lesson_id) {
                if (get_post_status($lesson_id) !== 'publish') continue;
                $li = self::render_lesson_li($lesson_id, $uid, $current_lesson_id, $is_sidebar);
                $items .= $li['html'];
                if (!$li['complete']) $group_complete = false;
                if ($li['is_current']) $group_has_current = true;
            }
            if ($items === '') continue;
            if ($group['title'] === '') {
                $out .= $items;
            } else {
                $open_attr = (!$group_complete || $group_has_current) ? ' open' : '';
                $out .= '<li class="bhc-module-group"><details' . $open_attr . '><summary class="bhc-module-title">' . esc_html($group['title']) . '</summary><ol class="bhc-lesson-list bhc-module-lesson-list">' . $items . '</ol></details></li>';
            }
        }
        $out .= '</ol>';
        return $out;
    }

    // Shared between the catalog card (BHC_Render_Catalog) and this
    // course page itself — both need the exact same "where should this
    // student go next" decision, just rendered at different sizes.
    // $percent is passed in rather than recomputed since both call sites
    // already have it (or compute it themselves right before calling
    // this).
    public static function render_continue_cta(int $uid, int $course_id, int $percent): string {
        $target_lesson = BHC_Progress::first_incomplete_lesson($uid, $course_id);
        if ($target_lesson) {
            $label = $percent > 0 ? 'Continue' : 'Start';
            return '<a class="bhc-btn bhc-continue-btn" href="' . esc_url(get_permalink($target_lesson)) . '">' . esc_html($label) . ' &rarr;</a>';
        }
        // Nothing left to resume into — either genuinely 100% done, or
        // every lesson is either empty or drip-locked (first_incomplete_lesson()
        // can't tell those apart, and neither needs a CTA either way).
        // Only show "Review" once actually complete, not for the
        // ambiguous "nothing open yet" case.
        if ($percent >= 100) {
            $lesson_ids = BHC_PostTypes::lesson_order($course_id);
            if ($lesson_ids) {
                return '<a class="bhc-btn bhc-btn-secondary bhc-continue-btn" href="' . esc_url(get_permalink($lesson_ids[0])) . '">Review course</a>';
            }
        }
        return '';
    }

    /**
     * The biggest single payoff moment in this whole redesign — replaces
     * what used to be a bare "Download certificate" link with a real
     * dedicated completion state: stats pulled from data already tracked
     * (no new storage), the certificate/share card promoted from
     * afterthought links to the actual centerpiece, and a clear next
     * step. Returns '' (renders nothing) unless this specific student
     * has actually completed this specific course — never a
     * congratulations screen shown speculatively.
     *
     * $assume_complete: for the one caller (class-render-lesson.php's
     * final-step reveal) where the completion write is GUARANTEED to
     * have just happened by construction — this markup is server-
     * rendered at page LOAD (before the student has clicked anything),
     * then revealed client-side only after the final step's own AJAX
     * call succeeds. is_course_completed() at render time would still
     * read false on a student's first-ever completion (the DB write
     * hasn't happened yet at that point), so that one call site passes
     * true to skip the check it would otherwise incorrectly fail.
     */
    public static function render_completion_screen(int $uid, int $course_id, bool $assume_complete = false): string {
        if (!$uid || !class_exists('BHC_Progress')) return '';
        if (!$assume_complete && !BHC_Progress::is_course_completed($uid, $course_id)) return '';

        $lesson_count = BHC_PostTypes::lesson_count($course_id);
        $quizzes_passed = BHC_Progress::quizzes_passed_count($uid, $course_id);
        $quiz_average = BHC_Progress::course_quiz_average($uid, $course_id);
        $enrolled_at = BHC_Progress::enrolled_at($uid, $course_id);
        $completed_at = BHC_Progress::course_completed_at($uid, $course_id);
        $has_certificate = class_exists('BHC_Certificates') && BHC_Certificates::course_offers_certificate($course_id);
        $has_share_card = class_exists('BHC_ShareCards');
        $distinction_threshold = (int) apply_filters('bhc_certificate_distinction_threshold', 90);
        $with_distinction = $quiz_average !== null && $quiz_average >= $distinction_threshold;

        ob_start();
        // '.bhc-completion' (not a new wrapper class) so this inherits
        // the existing gradient-ring surface treatment AND the one-shot
        // confetti burst courses.js already fires for any element found
        // at that exact selector (querySelector('.bhc-completion')) —
        // one visual language for this moment, not two.
        echo '<div class="bhc-completion">';
        echo '<div class="bhc-completion-badge" aria-hidden="true">&#127942;</div>';
        echo '<h2 class="bhc-completion-title">Course complete' . ($with_distinction ? ' — with distinction' : '') . '!</h2>';
        echo '<p class="bhc-completion-sub">You finished <strong>' . esc_html(get_the_title($course_id)) . '</strong>.</p>';

        echo '<div class="bhc-completion-stats">';
        echo '<div class="bhc-completion-stat"><span class="bhc-completion-stat-num">' . (int) $lesson_count . '</span><span class="bhc-completion-stat-label">lesson' . ($lesson_count === 1 ? '' : 's') . ' completed</span></div>';
        if ($quizzes_passed > 0) {
            echo '<div class="bhc-completion-stat"><span class="bhc-completion-stat-num">' . (int) $quizzes_passed . '</span><span class="bhc-completion-stat-label">quiz' . ($quizzes_passed === 1 ? '' : 'zes') . ' passed</span></div>';
        }
        if ($enrolled_at && $completed_at) {
            $days = max(1, (int) round((strtotime($completed_at) - strtotime($enrolled_at)) / DAY_IN_SECONDS));
            echo '<div class="bhc-completion-stat"><span class="bhc-completion-stat-num">' . $days . '</span><span class="bhc-completion-stat-label">day' . ($days === 1 ? '' : 's') . ' start to finish</span></div>';
        }
        echo '</div>';

        if ($has_certificate || $has_share_card) {
            echo '<div class="bhc-completion-actions">';
            if ($has_certificate) {
                echo '<a class="bhc-btn bhc-btn-primary" href="' . esc_url(BHC_Certificates::download_url($course_id)) . '">Download certificate' . ($with_distinction ? ' (with distinction)' : '') . '</a>';
            }
            if ($has_share_card) {
                // Audit fix (2026-07-25): opened a raw PNG in a new tab
                // with no download/save affordance — download attribute
                // makes the browser save it directly instead.
                echo '<a class="bhc-btn bhc-btn-secondary" href="' . esc_url(BHC_ShareCards::card_url($uid, $course_id)) . '" target="_blank" rel="noopener" download>Get share image</a>';
            }
            echo '</div>';
        }
        // The actual generated share card, shown inline — the whole
        // point of a share card is to be SEEN, not filed behind a link
        // nobody clicks to preview first.
        if ($has_share_card) {
            echo '<img class="bhc-completion-share-preview" src="' . esc_url(BHC_ShareCards::card_url($uid, $course_id)) . '" alt="' . esc_attr(get_the_title($course_id)) . ' completion share card" loading="lazy">';
        }

        echo '<div class="bhc-completion-next-steps">';
        $archive_url = get_post_type_archive_link('bh_course');
        if ($archive_url) echo '<a href="' . esc_url($archive_url) . '">Browse more courses</a>';
        if (class_exists('BHC_Reviews')) echo ' &middot; <a href="#bhc-reviews">Leave a review</a>';
        echo '</div>';
        echo '</div>';
        return ob_get_clean();
    }

    /**
     * The queue's real starting line — shown exactly once, the moment
     * BHC_Progress::enroll_if_needed() confirms a genuine first
     * enrollment. Reuses the same grouped-lesson-list markup the
     * ordinary progress view renders (render_grouped_lesson_list()) so
     * a student sees the real syllabus they're about to work through,
     * not a generic "you're enrolled!" toast with no substance.
     */
    /** @param array<int, int> $lesson_ids */
    private static function render_orientation_screen(int $uid, int $course_id, array $lesson_ids): string {
        ob_start();
        echo '<div class="bhc-orientation">';
        echo '<p class="bhc-orientation-eyebrow">You\'re in</p>';
        echo '<h2 class="bhc-orientation-title">Here\'s what\'s ahead</h2>';
        $content = get_post_field('post_content', $course_id);
        if ($content) {
            echo '<div class="bhc-orientation-description">' . wp_kses_post(get_the_excerpt($course_id) ?: wp_trim_words(wp_strip_all_tags($content), 40)) . '</div>';
        }
        if ($lesson_ids) {
            echo '<ol class="bhc-lesson-list bhc-orientation-syllabus">';
            foreach ($lesson_ids as $lesson_id) {
                if (get_post_status($lesson_id) !== 'publish') continue;
                echo '<li><span>' . esc_html(get_the_title($lesson_id)) . '</span></li>';
            }
            echo '</ol>';
        }
        // first_incomplete_lesson() (not a bare $lesson_ids[0]) — same
        // drip-lock/unpublished/no-steps skipping render_continue_cta()
        // already relies on, so "Start" never links to a lesson that
        // isn't actually open yet on day one of a drip-scheduled course.
        $start_lesson = BHC_Progress::first_incomplete_lesson($uid, $course_id);
        if ($start_lesson) {
            echo '<a class="bhc-btn bhc-orientation-start" href="' . esc_url(get_permalink($start_lesson)) . '">Start &rarr;</a>';
        }
        echo '</div>';
        return ob_get_clean();
    }
}
