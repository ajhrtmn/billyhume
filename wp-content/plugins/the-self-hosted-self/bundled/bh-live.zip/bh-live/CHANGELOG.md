# Changelog — BH Live

Moved out of `bh-live.php` on 2026-08-25 — this plugin never got the same extraction the-self-hosted-self did on 2026-08-23, so its version history sat in source comments until now. See `CONVENTIONS.md` for why version history lives here and in git rather than in source.

Entries are newest-first, exactly as written in-file. Nothing reworded or dropped.

---

0.9.6 — Continued the live-robustness pass onto this plugin's other two
Cloudflare integrations (`BHL_WorkersChat`, `BHL_CloudflareStreamEngine`),
following the same thread as 0.9.5's Fly provisioner fix — done
thoroughly rather than stopping at the first finding.

`BHL_WorkersChat` had NO way to tear down a deployed chat Worker at
all. Once deployed, this is a real, publicly reachable, anonymous-and-
unmoderated WebSocket chat endpoint (per this class's own docblock) —
switching the site's active chat engine away from Workers only stopped
this plugin from linking to it, the Worker itself (and its Durable
Object) kept running and kept accepting messages indefinitely, with the
wizard section for it no longer even rendering to remind anyone it
existed. Added `undeploy()` (real Cloudflare Workers `DELETE` endpoint,
404-tolerant — an already-manually-deleted script is success, not a
stuck error) and a wizard "Remove chat Worker" action that now appears
whenever a deployment exists, even after switching to a different chat
engine.

`BHL_CloudflareStreamEngine::create_live_input()`'s own wizard button is
labeled "replaces the one above" but never actually deleted the
previous live input — only overwrote the locally stored UID, leaving
the old one live on the Cloudflare account with the UI actively
misrepresenting it as gone. Now genuinely replaces it (best-effort
delete of the old UID after the new one is confirmed created, logged
if that cleanup fails, never allowed to block getting a working stream
key). Also added a standalone "Remove live input" action so one doesn't
have to be created just to delete the current one.

Both fixes reuse the same `['status' => $code]` WP_Error-data pattern
0.9.5 introduced for Fly, verified against the real local install with
`pre_http_request` filters standing in for Cloudflare's real API (never
call a real cloud API from a verification pass): a mocked create+delete
round trip confirmed the old live input is genuinely deleted and the
new one is stored correctly; a mocked 404 correctly clears
`BHL_WorkersChat`'s deployed flag while a mocked 500 is still correctly
reported as a real failure.

0.9.5 — Live-robustness pass on `BHL_FlyProvisioner` (Fly.io Machines
host provisioning). Real gap found: `destroy()` requires a machine to
actually still exist to succeed — if it was ever deleted directly via
Fly's own dashboard/CLI (outside this plugin entirely), the stored
`active_machine_id` had no way back to a clean state. The next
"Destroy machine" click just failed again with the same error forever,
and the media wizard's own status check silently rendered nothing at
all when it failed, leaving an admin looking at a bare button with zero
context. Fixed: `request()` now carries the real HTTP status on its
`WP_Error` (`['status' => $code]`), and `destroy()` treats a 404 —
"the goal state is already true, there's nothing left to delete" — as
success rather than failure, clearing the stale reference. The wizard
(`the-self-hosted-self`'s `class-media-wizard.php`) now shows the
actual error message instead of going blank when a status check fails.

Verified against the real local install with `pre_http_request`
filters standing in for Fly's real API (never call a real cloud
provisioning API from a verification pass): a simulated 404 correctly
clears `active_machine_id`, while a simulated 500 is still correctly
reported as a real failure, not silently swallowed alongside it.

0.9.4 — Ecosystem quality Phase 2, brick 6/13: added native return/
parameter types across all 20 includes files (211 findings, both
mechanical level-6 categories) — the largest brick so far. Two real
interfaces (BHL_StreamEngine, BHL_HostProvisioner, BHL_Chat) got
typed method contracts, with every implementing class (Owncast/
Cloudflare engines, Fly provisioner, polling/workers/Owncast chat)
matched to them. One deliberate exception: BHL_FlyProvisioner::
settings()'s return type is `array<string, string>`, not a precise
shape — the-self-hosted-self's class-media-wizard.php also reads this
method's return value with its own `?? ''` fallbacks, and a precise
shape there made those fallbacks flag as "always exists," a
cross-plugin false positive a same-plugin fix can't clean up
without touching the-self-hosted-self (a separate, later brick). Purely
additive typing otherwise, no behavior change.
NOT runtime-verified against a live install.

0.9.3 — This plugin's first PHPStan pass (newly added to
phpstan.neon's scanned paths this round — the-self-hosted-self's own
class-media-wizard.php interaction with this plugin's BHL_* classes
is also now for real type-checked instead of unresolved noise, and
came back clean). Fixed esc_attr() needing a string, not the int $vid
it was given directly (class-admin.php); dropped an unnecessary
accepted_args count on 3 mock closures in class-test-suite.php that
never used their args (same pattern already fixed in bh-registry).
NOT runtime-verified against a live install — confirmed via a real
`vendor/bin/phpstan analyse` run. `php -l` clean.

0.1.0 — scaffold (2026-07-26, wondrous-mixing-forest.md): Owncast
decided for v1 specifically because it bundles chat + a web player +
RTMP ingest in one deployable unit, making it the easiest real thing
to integrate first — behind bh-live's own BHL_StreamEngine interface
(class-stream-engine.php) so a later OvenMediaEngine implementation
is a second class, not a rewrite.

Since grown well beyond that first scaffold, same session: chat IS
now abstracted (class-chat.php's BHL_Chat interface), with three
real implementations — Owncast's own bundled chat, a free polling-
based BHL_PollingChat (matching bh-streaming's own Jam sessions'
proven pattern), and a real-time BHL_WorkersChat via a Cloudflare
Worker + Durable Object — plus BHL_CloudflareStreamEngine as a
second BHL_StreamEngine, and BHL_HostProvisioner/BHL_FlyProvisioner
for deploying the Owncast box directly from the wizard. See
STATUS.md for the full current picture.

A live stream genuinely cannot run on ordinary shared hosting —
real-time RTMP ingest/transcoding needs its own dedicated box. This
plugin is intentionally just the thin WordPress-side integration
layer (read live status, embed the player, manage the connection
settings) — see BHL_OwncastEngine's own docblock for exactly what it
does and doesn't do.
