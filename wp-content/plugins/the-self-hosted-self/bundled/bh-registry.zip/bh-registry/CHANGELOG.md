# Changelog — BH Registry

Moved out of `bh-registry.php` on 2026-08-23. See `CONVENTIONS.md` for why version history lives here and in git rather than in source.

Entries are newest-first, exactly as written in-file. Nothing reworded or dropped.

---

0.1.21 — OPEN.md item 8: the "This Site's Identity" token field
(`render_identity_box()`) clipped its own monospace token value at
375px (confirmed: `scrollWidth 331 > clientWidth 309`) with no visual
indication anything was cut off. Fixed with `text-overflow:ellipsis` +
`white-space:nowrap` — a visual truncation only; `onclick="this.
select()"` still selects and copies the real, full, un-truncated
value regardless of how much is visibly shown. Found and verified via
the real Playwright admin audit, run for the first time ever with real
credentials this pass (see the-self-hosted-self 3.15.5's own entry for
the harness fixes that made this possible).

0.1.20 — Security fix found during a live-robustness audit of this
plugin's federation surface: `BHR_Verification`'s three outbound checks
(`check_domain_ownership()`, `check_activitypub_actor()`,
`check_open_feed()`) fetch a URL taken directly from `$link->url` — a
fully public, self-serve submission (POST /submissions) — with NO
guard at all, unlike `BHR_Crawl`'s own peer-manifest fetches, which
already run every URL through `is_safe_external_url()` (a DNS-
resolution-aware check rejecting private/loopback/link-local/reserved
ranges and non-http(s) schemes, purpose-built for exactly this SSRF
shape). An unauthenticated submission could have pointed this server's
own outbound request at an internal service or a cloud metadata
endpoint (169.254.169.254) and had the response reflected back into
this site's own verification state. Fixed by reusing the existing
`BHR_Crawl::is_safe_external_url()` check at all three call sites
rather than duplicating the logic.

Verified against the real local WP+MySQL install via reflection
(all three are private methods): `localhost`, `169.254.169.254`, and
RFC1918 addresses (`192.168.x.x`, `10.x.x.x`) are all rejected before
any outbound request is attempted, while a real public URL
(`https://github.com/`) still passes the same check unaffected.

0.1.19 — Real redesign of 0.1.18's discovery mechanism, prompted by
direct, in-session feedback after 0.1.18 both caused a real
production outage (a mid-deploy race on Wasmer's file-sync, not a
genuine code bug — confirmed by a clean redeploy of the identical
code after a real wait) AND turned out to have a genuine, separate
design bug once live-tested: the "Add Peer" form only auto-generated
a secret, with no way to manually enter the secret the OTHER side
had generated, so two independently-added peers could never actually
agree on a shared secret — bidirectional gossip could never have
worked as built. That bug is what prompted the real question: "That
still requires human input? Not like web crawlers for discovery?",
then "It shouldn't be manual at all - 100% automatic", then "No
previous knowledge of one another should be required" — each a real
rejection of the mutual-secret-exchange model, not scope creep.

Replaced entirely (not patched) with an open, unauthenticated
PULL/crawl model: class-gossip.php -> class-crawl.php (BHR_Gossip ->
BHR_Crawl, the whole mental model changed from push-announce to
pull-crawl). New GET /bhr/v1/peers/manifest (open, __return_true,
like every other read route here) replaces POST /peers/announce and
GET /peers/handshake entirely — no secret, no privileged inbound
endpoint, no per-relationship setup beyond knowing a base_url. A
daily cron crawls each active peer's manifest, ingests its verified
links as candidates (still, unchanged, only ever a thin pointer
queued for THIS site's own independent BHR_Verification::verify_link()
check — never a trust shortcut), and auto-follows each peer's own
known_peers list onward, hop-limited (bhr_peers.discovered_hop,
option bhr_crawl_max_hops, default 3) and capped
(BHR_Crawl::MAX_TOTAL_PEERS = 200) against unbounded growth from a
colluding cluster.

New, real attack surface this pull redesign introduces versus the
reverted push design: this site now fetches URLs a REMOTE PEER
merely CLAIMS exist (its known_peers list), not just URLs a local
admin chose — a genuine SSRF vector if unguarded. Added
BHR_Crawl::is_safe_external_url(): resolves the host, rejects any
private/loopback/link-local/reserved-range IP (RFC1918, 127.0.0.0/8,
169.254.0.0/16 — including cloud metadata endpoints — ::1, fc00::/7,
fe80::/10) and any non-http(s) scheme, checked before every single
outbound request to a peer-supplied URL, including the peer's own
base_url on every crawl (DNS can change after a peer was safely
added).

Direct follow-up: "Most interested in search index and activity
pub" — the two mechanisms actually capable of true
zero-prior-knowledge discovery (neither site having ever heard of
the other), since nothing built from only two from-scratch nodes can
bootstrap that alone; every real decentralized system leans on
something already operating at internet scale for this (BitTorrent's
bootstrap nodes, Mastodon's relay/WebFinger model, DNS's root
servers). Built now: BHR_SearchDiscovery (class-search-discovery.php)
— an optional, OFF BY DEFAULT weekly job querying an admin-configured
search endpoint (a self-hostable SearXNG instance recommended over a
paid vendor API — genuinely avoids a silent third-party dependency;
a commercial API works too if that's what's configured) for other
public installs, feeding any confirmed-real hit into the exact same
BHR_Crawl::maybe_add_discovered_peer() pipeline a directly-crawled
peer-of-a-peer uses. Settings follow the-self-hosted-self's own established
Tier B pattern (class-media-wizard.php's Cloudflare Stream section —
confirmed via direct exploration, not guessed): toggle + credential,
password field always blank, a blank submit preserves the existing
stored value.

ActivityPub relay integration (the other priority layer) is
DELIBERATELY NOT built in this version — real, existing Fediverse
relay infrastructure already solves zero-prior-knowledge discovery
for the activitypub protocol at internet scale today, but doing it
correctly needs a real minimal ActivityPub actor (WebFinger
discovery, an actor JSON endpoint, HTTP Signature verification for
authenticated Follow/Accept/Announce activities) — genuine
cryptographic-correctness-stakes protocol work, not something to
rush in the same fast-iterating session that already had one real
production incident from insufficiently-tested code. Settings
fields (bhr_relay_enabled, bhr_relay_url) ARE added to the Peers
screen now, stored for when the actor implementation lands, but
nothing reads them yet.

Schema: DB_VERSION 1.2 -> 1.3 (class-activator.php). bhr_peers'
shared_secret/last_announced_at columns — genuinely dead after this
redesign — get a real ALTER TABLE DROP COLUMN (guarded, checks
existence first) rather than left as permanent unused schema;
justified specifically because zero real peer data exists anywhere
yet. New discovered_hop column added. bhr_links.discovered_via='crawl'
replaces the old 'gossip' value going forward (both mean "not
manually submitted" — provenance only, never affects verification).

NOT runtime-verified against a live install yet at the time this
entry was written — `php -l` clean on every touched/new file. Given
0.1.18's own incident, this version gets a real local-first
verification pass AND a genuine wait-before-recheck on live deploy
before being trusted, not an instant recheck (that's what produced
the false-alarm revert last time).

0.1.18 — Phase 2 of the peer gossip/announce plan (REVERTED, see
0.1.19 above — kept for incident record only, this version's own
push+secret design was replaced, not built on). Originally: the actual
protocol. New POST /bhr/v1/peers/announce (the inbound receiver —
the ONLY route in this namespace that isn't __return_true;
authenticated via a per-peer shared secret checked with hash_equals()
for timing-safe comparison, class-gossip.php's check_peer_auth())
and GET /bhr/v1/peers/handshake (open, a read-only self-description
used at peer-add time and by the new daily liveness cron). New admin
screen (class-peers.php, BHR_Peers) for adding/blocking/deleting
peers — peering is always an explicit, mutual, admin-initiated
action; this plugin never auto-discovers or auto-trusts anything.

Discovery and trust stay genuinely separate, on purpose: an accepted
announce candidate is a thin pointer (protocol+url only, nothing
else trusted) inserted through the EXACT SAME pending-row shape
POST /submissions already writes, then queued for this site's own
independent BHR_Verification::verify_link() check — completely
unchanged by any of this, never bypassed, never sped up. A peer
cannot make an artist appear "verified" by claiming so; only a real
domain-ownership + open-protocol check run BY THIS SITE can. Fan-out
to other peers only happens AFTER local verification succeeds (via
a new bhr/link_verified BH_Event, fired from verify_link()'s own
success branch, for ANY successfully-verified link regardless of
origin — one code path, no special-casing between manual and
gossip-discovered links), never on receipt of an unverified
candidate — a hostile/compromised peer cannot use this site to
inject a fake-verified artist into the wider gossip graph.

Real, deliberate abuse-surface hardening, since this is the first
endpoint in the plugin that both accepts remote input AND triggers
further outbound HTTP + DB writes on receipt: hop-limiting (receiver
always clamps to its OWN configured ceiling, ignores whatever the
sender's message claims), loop prevention (never re-announce back to
the peer a candidate was just received from), dedup via a new
bhr_gossip_seen table (a candidate already seen — from ANY peer, not
just the same one twice — is neither re-queued for verification nor
re-fanned-out), per-peer rate limiting (OUS_ReliableStore, 30
announces/minute, checked before any DB write), a hard cap on
candidates-per-announce (20) and raw body size (~20KB) checked
before JSON decode, and verification is NEVER synchronous inside the
announce request itself — always deferred to a queued job, so an
inbound POST can never be used to make this site perform slow
outbound fetches on an attacker's own timer.

DB_VERSION 1.1 -> 1.2 (class-activator.php): one more additive
bhr_links column, discovered_hop_count — found necessary while
actually wiring the fan-out logic (verification can be re-triggered
by several different paths — the queued job, the daily recheck cron,
a manual re-check — and the correct hop_count to propagate at needs
to survive all of them, so it lives on the row itself rather than
being threaded through every possible job-args call site).

Rollout stays exactly as scoped: a site with zero peers configured
behaves byte-for-byte as it did before this version — /peers/announce
always 401s (no secret exists to authenticate against), the fan-out
loop in announce_verified_link() is always empty, and every existing
route/behavior (submissions, verify, artists, feed-url, tracks) is
completely untouched.
NOT runtime-verified against a live install yet — `php -l` clean on
every touched/new file. Live verification (a real 2-site peer
exchange) and the deterministic simulation test suite are Phase 5,
still to come.

0.1.17 — Phase 1 of the peer gossip/announce plan: schema only, a
deliberate no-op deploy (DB_VERSION 1.0 -> 1.1, class-activator.php).
Two new tables — bhr_peers (an admin-added gossip partner: base_url,
status, shared_secret, liveness tracking) and bhr_gossip_seen (a
dedup/hop-limiting ledger, one row per (protocol,url) candidate hash)
— plus two additive bhr_links columns (discovered_via,
discovered_from_peer_id, pure provenance). Nothing reads or writes
any of this yet; the actual protocol/REST routes/propagation logic
is Phase 2, still to come. Verified: SHOW TABLES check in
create_or_update_schema() now confirms all 4 tables, not just the
original 2, before marking the migration successful.
NOT runtime-verified against a live install yet — `php -l` clean.

0.1.16 — Phase 0 of the peer gossip/announce discovery plan (real
gap found during a live cross-site federation test this session):
verifying this site's OWN feed on ANOTHER site's registry requires
publishing a token at https://{this-host}/.well-known/
bh-registry-verify.txt — a path outside wp-content that needs raw
filesystem/SSH access, confirmed genuinely unavailable on a real
Wasmer-hosted production install (wp-admin-only access) and a real
blocker on plenty of ordinary shared hosting too. Added
BHR_WellKnown (class-wellknown.php): self-serves that exact path via
a WP rewrite rule (same BHY_RewriteHealer::maybe_heal() self-healing
pattern BHI_Portal/BHM_Storefront already use), content from a new
admin-visible/regenerable bhr_wellknown_token option. A real static
file at the same path still wins if one exists — this only fills the
gap when one doesn't. BHR_Verification::check_domain_ownership()
itself is completely unchanged; it was always just an HTTP GET
against whatever host a submission claims — this only changes what
answers that GET on THIS site specifically. First piece of a larger,
fully-scoped peer gossip/announce plan (see the project's plan file)
— later phases add opt-in peer-to-peer propagation on top of this,
none of which is built yet.
NOT runtime-verified against a live install yet — `php -l` clean.

0.1.15 — Adds GET /bhr/v1/artists/{id}/tracks: a read-only preview
of a registered artist's actual tracks (fetches and parses their
feed live via fetch_feed(), same enclosure-extraction approach
bh-streaming's own importer uses, never importing or storing
anything locally) — the piece a fan-facing "browse the global
library" feature needs that didn't exist anywhere: this registry
only ever knew ARTIST-level entries (a feed URL), never individual
tracks within one. Building and live-testing this endpoint is what
surfaced a real, significant, separate bug in bh-streaming's own
feed EXPORT (see bh-streaming 0.5.30's own changelog for the full
story) — this endpoint's honest "feed_unreachable" error, and the
real WP_Error message temporarily surfaced for debugging, is what
proved the export side had been silently broken this whole time.
Verified live end-to-end after that fix landed: pointed a temporary
test artist at this site's own real feed, confirmed real track data
(title/artist/audio_url/duration) round-tripped correctly, then
cleaned up the test data.

0.1.14 — Real gap found in a direct vision check with AJ: the
bh-streaming bridge (class-streaming-bridge.php) only ever gave an
admin a search box on the Feed Sources screen — being registered
never surfaced an artist automatically, only made them findable if
searched for by name, nowhere close to "a global library the admin
has to choose from to curate." The REST endpoint (GET /bhr/v1/
artists) already fully supported a blank-search browse-all query
with protocol filtering — this was a pure admin-UI gap, no backend
work needed. Added a real "Browse Registry" admin screen
(BHR_StreamingBridge::render_browse_page(), still guarded by
class_exists('BHS_Feeds') — bh-registry still never requires
bh-streaming) showing every verified feed-protocol artist as a
card, with a real one-click "Add to my library" action
(handle_add_from_registry()) that creates a real bhs_feed_source
post and triggers an IMMEDIATE sync via BHS_Feeds::sync_one_job()
(the same public entry point the cron/job-queue fan-out already
use, not a duplicated fetch), rather than waiting up to 12 hours for
the next cron tick. Reuses BHR_API::list_artists()/get_feed_url()'s
real, already-tested query logic via rest_do_request() (WordPress
core's own internal REST dispatch) instead of duplicating SQL.
Verified live end-to-end: temporarily marked one seed link
verified, confirmed the card rendered, clicking "Add to my library"
created a real bhs_feed_source post with the correct feed URL meta
and correctly flipped the card to "Already in your library" —
confirmed via direct DB query, then reverted the test state
afterward. The second half of AJ's actual vision — a fan-facing,
platform-independent cross-site library — is explicitly scoped as
its own future design pass, not started here.

0.1.13 — Same SEO-timing bug found and fixed on bh-courses this
session, same fix here: BHR_Frontend::render()'s SEO block only ever
ran during the_content() (the [bh_registry] shortcode's own
render), always after wp_head — where BH_SEO actually echoes its
tags — has already fired. Extracted into its own set_seo_data()
method and added a template_redirect hook that detects the
shortcode on the current page early, via
BH_SEO::shortcode_atts_on_current_page() (the-self-hosted-self) — confirmed
live, the Artist Registry page now renders real meta/OG tags.

0.1.12 — Real bug fix surfaced by the-self-hosted-self's own final PHPStan
level 6 brick (typing OUS_Debug::button() with a real `: void`
return): class-debug.php here was calling it as `echo
OUS_Debug::button(...)`, double-printing that debug-tools button on
this plugin's own Debug Tools section — button() already echoes its
own markup internally, the wrapping `echo` was pure extraneous
output. Fixed by dropping the `echo`. NOT runtime-verified against a
live install; smoke-test the Debug Tools page to confirm the button
renders once, not twice.

0.1.11 — Ecosystem quality Phase 2, brick 5/13: added native return
types and parameter types across all 11 includes files (94 findings,
both mechanical level-6 categories). $wpdb->get_row()/get_results()
rows are typed \stdClass (their real default object shape) rather
than array — matches how every method in this plugin actually reads
them (->id, ->url, etc., not ['id']). Purely additive typing, no
behavior change. This plugin is now clean at PHPStan level 6 in
isolation.
NOT runtime-verified against a live install.
0.1.10 — PHPStan round 2 (this plugin went from 9 errors to 0): all
9 findings were the same real, if harmless, mismatch in
class-test-suite.php — add_filter('pre_http_request', $filter, 10, 3)
declared 3 accepted args for mock closures that only ever declared
zero (function () { return [...]; }), since they return a fixed
canned response regardless of the request. Dropped the unnecessary
accepted_args count on the 9 closures that genuinely never use their
args; the 2 closures elsewhere in the same file that DO use
($preempt, $args, $url) were left untouched.
NOT runtime-verified against a live install — confirmed via a real
`vendor/bin/phpstan analyse` run. `php -l` clean.

0.1.2 — All three remote-verification checks (domain ownership challenge,
open-feed fetch, ActivityPub actor fetch) now surface the actual failure
reason instead of discarding it, so "not verified" distinguishes
"never set up" from "our request to your server failed".
0.1.3 — bundled zip regenerated to match installed version, no code change.
0.1.4 — class-debug.php's register() now sets 'group' =>
OUS_Debug::GROUP_SEED_RESET, part of the Debug Tools reorganization.
0.1.5 — OUS_Search consumer. Reuses BHR_API::list_artists()'s
'active'/verified-only gate, so pending/rejected artists never surface in
search. Links to the registry directory page since no per-artist
canonical URL exists yet (the directory is one client-rendered page).
