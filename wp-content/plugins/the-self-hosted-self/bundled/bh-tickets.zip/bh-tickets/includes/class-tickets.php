<?php
if (!defined('ABSPATH')) exit;

/**
 * BHT_Tickets — core CRUD, and this plugin's OUS_Integration built-in
 * default (see bh-tickets.php's registration). Every ticket belongs to
 * a real wp_user (bh-crm's own identity model — a person IS a
 * wp_users row, per CLAUDE.md); no separate contact/identity system,
 * same reasoning that ruled out FluentCRM/Groundhogg for the marketing
 * layer applies here too. A ticket links to its requester via
 * BHCRM_Links (already-existing generic typed relationship table) when
 * bh-crm is active — entirely optional, this plugin works standalone.
 */
class BHT_Tickets {
    const STATUSES = ['open' => 'Open', 'pending' => 'Pending', 'resolved' => 'Resolved', 'closed' => 'Closed'];
    const PRIORITIES = ['low' => 'Low', 'normal' => 'Normal', 'high' => 'High'];

    private static function table(): string {
        return BHT_Tables::tickets();
    }

    /** @return int|\WP_Error */
    public static function create(int $user_id, string $subject, string $body, string $category = '', string $priority = 'normal') {
        global $wpdb;
        $subject = sanitize_text_field($subject);
        if (!$user_id || $subject === '') return new WP_Error('invalid', 'A ticket needs a real account and a subject.');

        $priority = isset(self::PRIORITIES[$priority]) ? $priority : 'normal';

        $wpdb->insert(self::table(), [
            'user_id' => $user_id,
            'subject' => $subject,
            'category' => sanitize_text_field($category),
            'priority' => $priority,
            'status' => 'open',
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql'),
        ]);
        $ticket_id = (int) $wpdb->insert_id;
        if (!$ticket_id) return new WP_Error('db_error', 'Could not create the ticket.');

        // The opening message is itself the first reply — one thread,
        // no separate "ticket body" field to keep in sync with replies.
        if (class_exists('BHT_Replies')) {
            BHT_Replies::add($ticket_id, $user_id, $body, false);
        }

        if (class_exists('BHCRM_Links')) {
            BHCRM_Links::link('ticket', $ticket_id, 'person', $user_id, 'requester');
        }

        if (class_exists('BH_Event')) {
            BH_Event::emit('bht/ticket_created', [
                'user_id' => $user_id, 'subject_type' => 'bht_ticket', 'subject_id' => $ticket_id,
                'payload' => ['subject' => $subject, 'category' => $category, 'priority' => $priority],
            ]);
        }

        self::notify_staff_new_ticket($ticket_id, $user_id, $subject);

        return $ticket_id;
    }

    // Real gap found in a functional-depth audit: BHT_Replies'
    // maybe_notify() already handles staff-reply and requester-reply
    // notifications, but its own doc comment openly says a brand-new,
    // unassigned ticket notifies nobody — "no dedicated ticket-manager
    // role/list beyond the bhcore_manage_tickets capability." That gap
    // was never actually closed: bht/ticket_created fires for the
    // event log but nothing ever listened to it for notification
    // purposes. A support plugin whose own description promises "staff
    // triage from wp-admin" needs staff to actually find out a ticket
    // exists — closing it here rather than leaving new tickets
    // invisible until someone happens to check the list. Notifies
    // every account holding bhcore_manage_tickets (there's still no
    // dedicated ticket-manager role/list to narrow it further — the
    // same real constraint the reply-notification code already
    // documented), skipping the creator themself in case a staff
    // member opens a ticket on their own behalf.
    private static function notify_staff_new_ticket(int $ticket_id, int $creator_id, string $subject): void {
        if (!class_exists('OUS_Notifications')) return;
        $staff = get_users(['capability' => 'bhcore_manage_tickets']);
        if (!$staff) return;
        $url = admin_url('admin.php?page=bh-tickets&ticket_id=' . $ticket_id);
        foreach ($staff as $user) {
            if ((int) $user->ID === $creator_id) continue;
            OUS_Notifications::notify(
                (int) $user->ID, 'ticket_created',
                'New support ticket: ' . $subject,
                'A new ticket needs triage.',
                $url, 'BH Tickets'
            );
        }
    }

    /**
     * $wpdb returns every column as a string, including bigint keys. Callers
     * that compare an id strictly -- in_array($id, array_column($rows,'id'), true)
     * is the one the test suite does -- then never match, because "12" !== 12.
     * Normalising here rather than at each call site is what makes the
     * array<int,...> shapes these methods document actually true.
     *
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    private static function normalise(array $row): array {
        foreach (['id', 'user_id', 'assigned_to', 'ticket_id'] as $col) {
            if (isset($row[$col])) $row[$col] = (int) $row[$col];
        }
        return $row;
    }

    /** @return array<string, mixed>|null */
    public static function get(int $ticket_id): ?array {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::table() . ' WHERE id = %d', $ticket_id), ARRAY_A);
        return is_array($row) ? self::normalise($row) : null;
    }

    /**
     * Every ticket a given user opened, newest first.
     * @return array<int, array<string, mixed>>
     */
    public static function for_user(int $user_id): array {
        global $wpdb;
        $rows = $wpdb->get_results($wpdb->prepare(
            'SELECT * FROM ' . self::table() . ' WHERE user_id = %d ORDER BY updated_at DESC', $user_id
        ), ARRAY_A);
        return array_map([self::class, 'normalise'], is_array($rows) ? $rows : []);
    }

    /**
     * The staff-facing list — optionally filtered by status.
     * @return array<int, array<string, mixed>>
     */
    public static function all(string $status = ''): array {
        global $wpdb;
        if ($status && isset(self::STATUSES[$status])) {
            $rows = $wpdb->get_results($wpdb->prepare(
                'SELECT * FROM ' . self::table() . ' WHERE status = %s ORDER BY updated_at DESC', $status
            ), ARRAY_A);
            return array_map([self::class, 'normalise'], is_array($rows) ? $rows : []);
        }
        $rows = $wpdb->get_results('SELECT * FROM ' . self::table() . ' ORDER BY updated_at DESC', ARRAY_A);
        return array_map([self::class, 'normalise'], is_array($rows) ? $rows : []);
    }

    public static function set_status(int $ticket_id, string $status): bool {
        global $wpdb;
        if (!isset(self::STATUSES[$status])) return false;
        $ticket = self::get($ticket_id);
        if (!$ticket) return false;

        $wpdb->update(self::table(), ['status' => $status, 'updated_at' => current_time('mysql')], ['id' => $ticket_id]);

        if (class_exists('BH_Event')) {
            BH_Event::emit('bht/status_changed', [
                'user_id' => (int) $ticket['user_id'], 'subject_type' => 'bht_ticket', 'subject_id' => $ticket_id,
                'payload' => ['status' => $status],
            ]);
        }
        return true;
    }

    public static function assign(int $ticket_id, int $staff_user_id): bool {
        global $wpdb;
        return $wpdb->update(self::table(), [
            'assigned_to' => $staff_user_id, 'updated_at' => current_time('mysql'),
        ], ['id' => $ticket_id]) !== false;
    }

    public static function touch(int $ticket_id): void {
        global $wpdb;
        $wpdb->update(self::table(), ['updated_at' => current_time('mysql')], ['id' => $ticket_id]);
    }

    /**
     * Optional enrichment of bh-crm's person view — same
     * bh_crm_activity_summary contract every other peer plugin uses,
     * harmless to register even if bh-crm is never active.
     * @param array<int, array<string, mixed>> $sections
     * @return array<int, array<string, mixed>>
     */
    public static function register_crm_activity(array $sections, int $user_id): array {
        $tickets = self::for_user($user_id);
        if (!$tickets) return $sections;
        $open = count(array_filter($tickets, fn($t) => in_array($t['status'], ['open', 'pending'], true)));
        $sections[] = [
            'plugin' => 'BH Tickets',
            'summary' => count($tickets) . ' ticket' . (count($tickets) === 1 ? '' : 's') . ($open ? ", $open open" : ''),
            'render' => function () use ($tickets) {
                echo '<table class="widefat striped"><thead><tr><th>Subject</th><th>Status</th><th>Updated</th></tr></thead><tbody>';
                foreach ($tickets as $t) {
                    $url = admin_url('admin.php?page=bh-tickets&ticket_id=' . (int) $t['id']);
                    echo '<tr><td><a href="' . esc_url($url) . '">' . esc_html($t['subject']) . '</a></td>'
                       . '<td>' . esc_html(self::STATUSES[$t['status']] ?? $t['status']) . '</td>'
                       . '<td>' . esc_html($t['updated_at']) . '</td></tr>';
                }
                echo '</tbody></table>';
            },
        ];
        return $sections;
    }
}
